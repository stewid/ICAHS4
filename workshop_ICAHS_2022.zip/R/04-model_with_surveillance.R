## "@ -> sample > 0 ? 0 : sample_frequency -> sample"

## "sample -> alpha * sample * (1 - pow(1 - Se * I / (S + I), n_samples)) -> result_pos"
## "sample -> alpha * sample * pow(1 - Se * I / (S + I), n_samples) -> result_neg"

## List the compartments
compartments <- c("S", "I", "sample", "result_pos", "result_neg")

## Define the transitions
transitions <- c(
    "S -> beta * S * I / (S + I) -> I",
    "I -> gamma * I -> S",
    "@ -> sample > 1 ? 0 : sample_frequency -> sample",
    "sample -> alpha * sample * (1 - pow(1 - Se * I / (S + I), n_samples)) -> result_pos",
    "sample -> alpha * sample * pow(1 - Se * I / (S + I), n_samples) -> result_neg")

## Set the parameter values
gdata <- c(beta = 0.16,
           gamma = 0.077,
           n_samples = 5,
           sample_frequency = 1/365,
           Se = 0.6,
           alpha = 1000)

## Declare the initial state
u0 <- data.frame(S = 99,
                 I = 1,
                 sample = 0,
                 result_pos = 0,
                 result_neg = 0)

## How long do you want to run the model.
tspan <- 1:1000

## Combine these pieces in the mparse function to generate a model you can
## run.
model <- mparse(transitions = transitions,
                compartments = compartments,
                gdata = gdata,
                u0 = u0,
                tspan = tspan)

set.seed(23)

result <- run(model)

## Plot the prevalence
plot(result, I ~ I + S)

## Plot the surveillance result
plot(result, ~ result_pos + result_neg)

set.seed(22)

gdata <- c(beta = 0.16,
           gamma = 0.077,
           n_samples = 30,
           sample_frequency = 12/365,
           Se = 0.2,
           alpha = 1000)

model <- mparse(transitions = transitions,
                compartments = compartments,
                gdata = gdata,
                u0 = u0,
                tspan = tspan)

result <- run(model)

## Plot the prevalence
plot(result, I ~ I + S)

## Plot the surveillance result
plot(result, ~ result_pos + result_neg)

## Add a few more infected individuals at the beginning and create 1000 population
u0 <- data.frame(S = rep(90, 10000),
                 I = 10,
                 sample = 0,
                 result_pos = 0,
                 result_neg = 0)

gdata <- c(beta = 0.16,
           gamma = 0.077,
           n_samples = 30,
           sample_frequency = 12/365,
           Se = 0.2,
           alpha = 1000)

model <- mparse(transitions = transitions,
                compartments = compartments,
                gdata = gdata,
                u0 = u0,
                tspan = tspan)

result <- run(model)

## plot the prevalence
plot(result, I ~ S + I, level = 3, range = 0.95)

## plot the surveillance results
plot(result, ~ result_pos, range = 0.95)
