knitr::include_graphics("img/overview.svg")

library(SimInf)

## List the compartments
compartments <- c("S", "I", "R")

## Define the transitions
transitions <- c("S -> beta*S*I/(S+I+R) -> I",
                 "I -> gamma*I -> R")

## Set the parameter values
gdata <- c(beta = 0.16,
           gamma = 0.077)

## Declare the initial state
u0 <- data.frame(S = 99, I = 1, R = 0)

## How long do you want to run the model:
tspan <- 1:100

## Combine these pieces in the mparse function to generate a model you can
## run:
model <- mparse(transitions = transitions,
                compartments = compartments,
                gdata = gdata,
                u0 = u0,
                tspan = tspan)

## "From_compartment -> Rate_calculation -> Destination_compartment"

## "S -> death_rate * S -> @"

## "@ -> birth_rate -> S"

## plot(run(model))
set.seed(5)
plot(run(model))

transitions <- c("S -> beta*S*I/(S+I+R) -> I",
                 "I -> gamma*I -> R",
                 "R -> alpha*R -> S")
compartments <- c("S", "I", "R")

u0 <- data.frame(S = 999, I = 1, R = 0)
tspan <- 1:1000

model <- mparse(transitions = transitions,
                compartments = compartments,
                gdata = c(beta = 0.16,
                          gamma = 0.077,
                          alpha = 0.05),
                u0 = u0,
                tspan = tspan)

## plot(run(model))
set.seed(5)
plot(run(model))

transitions <- c("S -> beta*S*I/(S+E+I+R) -> E",
                 "E -> epsilon*E -> I",
                 "I -> gamma*I -> R",
                 "R -> alpha*R -> S")
compartments <- c("S", "E", "I", "R")

u0 <- data.frame(S = 99, E = 1, I = 0, R = 0)
tspan <- 1:1000

model <- mparse(transitions = transitions,
            compartments = compartments,
            gdata = c(beta = 0.16,
                      epsilon = 0.3,
                      gamma = 0.1,
                      alpha = 0.1),
            u0 = u0,
            tspan = tspan)

## plot(run(model))
set.seed(5)
plot(run(model))
