## install.packages("remotes")
## remotes::install_github("stewid/debugme")

library(debugme)

## foo()

## ## [1] 0.25

## foo()

## ## [1] Inf

## foo()

## ## Error: Unable to determine 'x'.

## traceback()

## ## 3: stop("Unable to determine 'x'.", call. = FALSE)
## ## 2: foo_x()
## ## 1: foo()

## debug(debugme:::foo_x)

## foo()

## ## debugging in: foo_x()
## ## debug: {
## ##     if (runif(1) < 0.3)
## ##         stop("Unable to determine 'x'.", call. = FALSE)
## ##     1
## ## }
## ## Browse[2]>

## Browse[2]> n

## ## debug: if (runif(1) < 0.3) stop("Unable to determine 'x'.", call. = FALSE)
## ## Browse[2]>

knitr::include_graphics("img/gdb-code-1.png")

knitr::include_graphics("img/gdb-code-2.png")
