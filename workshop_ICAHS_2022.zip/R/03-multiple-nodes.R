knitr::include_graphics("img/temporal-network.svg")

events <- data.frame(
    event      = rep("extTrans", 6),  ## Event "extTrans" is a movement between nodes
    time       = c(1, 1, 2, 2, 3, 3), ## The time that the event happens
    node       = c(3, 3, 1, 4, 3, 4), ## In which node does the event occur
    dest       = c(4, 2, 3, 3, 2, 2), ## Which node is the destination node
    n          = c(9, 2, 8, 3, 5, 4), ## How many individuals are moved
    proportion = c(0, 0, 0, 0, 0, 0), ## This is not used when n > 0
    select     = c(1, 1, 1, 1, 1, 1), ## Use the 1st column in the model select matrix
    shift      = c(0, 0, 0, 0, 0, 0)) ## Not used in this example

events

E <- matrix(c(1, 1),
            nrow = 2,
            dimnames = list(c("S", "I")))

E

## Define the initial population
u0 = data.frame(S = c(10, 15, 20, 25),
                I = c( 5,  0,  0,  0))

## Define the transitions
transitions <- c("S -> beta * S * I / (S + I) -> I",
                 "I -> gamma * I -> S")

model <- mparse(transitions = transitions,
                compartments = c("S", "I"),
                gdata = c(beta = 0, gamma = 0),
                u0 = u0,
                tspan = 0:5,
                events = events,
                E = E)

trajectory(run(model))

u0 <- data.frame(S = c(90, 100, 100, 100),
                 I = c(10,   0,   0,   0))

events <- data.frame(
    event      = rep("extTrans", 4), ## Event "extTrans" is a movement between nodes
    time       = c(3, 25, 5, 10),    ## The time that the event happens
    node       = c(1, 1, 1, 1),      ## In which node does the event occur
    dest       = c(3, 2, 3, 3),      ## Which node is the destination node
    n          = c(1, 9, 1, 5),      ## How many animals are moved
    proportion = c(0, 0, 0, 0),      ## This is not used when n > 0
    select     = c(1, 1, 1, 1),      ## 1st column in the select matrix (see below)
    shift      = c(0, 0, 0, 0))      ## Not used in this example

set.seed(22)

model  <- mparse(transitions = c("S -> beta * S * I / (S + I) -> I",
                                 "I -> gamma * I -> S"),
                 compartments = c("S", "I"),
                 gdata = c(beta = 0.16, gamma = 0.077),
                 u0 = u0,
                 tspan = 1:75,
                 E = E,
                 events = events)

result <- run(model)

plot(result, ~I, range = FALSE)
