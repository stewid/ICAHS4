## List the compartments
compartments <- c("S", "I", "sample", "result_pos", "result_neg")

## Define the transitions
transitions <- c(
    "S -> beta * S * I / (S + I) -> I",
    "I -> gamma * I -> S",
    "@ -> sample > 1 ? 0 : sample_frequency -> sample",
    "sample -> alpha * sample * (1 - pow(1 - Se * I / (S + I), n_samples)) -> result_pos",
    "sample -> alpha * sample * pow(1 - Se * I / (S + I), n_samples) -> result_neg")

## Set the parameter values
gdata <- c(beta = 0.1,
           gamma = 0.07,
           n_samples = 5,
           sample_frequency = 1/365,
           Se = 0.6,
           alpha = 1000)

## Declare the initial state and add the compartments for
## surveillance. Here we use the 1600 herds from the package and
## simplify to just the 2 compartments in our model: S and I.
u0 <- u0_SISe()
u0$sample <- 0
u0$result_neg <- 0
u0$result_pos <- 0

## Infect a few individuals at the beginning of the study period
u0$I <- as.integer(0.01 * u0$S)
u0$S <- u0$S - u0$I

## load the example animal movement events from SimInf. Again do a
## little simplification since our model only has 2 compartments.
events <- events_SISe()

## define the select matrix for these events
E <- matrix(c(1, 1,
              0, 1,
              0, 0,
              0, 0,
              0, 0),
            byrow = TRUE,
            ncol = 2,
            dimnames = list(compartments))

## How long do you want to run the model:
tspan <- seq(from = min(events$time), to = max(events$time))

## Combine these pieces in the mparse function to generate a model you can
## run:
model <- mparse(transitions = transitions,
                compartments = compartments,
                gdata = gdata,
                u0 = u0,
                tspan = tspan,
                events = events,
                E = E)

summary(events(model))

set.seed(23)

result <- run(model)

## Plot the herd-level prevalence
plot(result, I ~ I + S, level = 2)

## Get the results of the trajectory
df <- trajectory(result)

## Summarize the number of negative and positive per day
n_negative <- tapply(df$result_neg, df$time, sum)
n_positive <- tapply(df$result_pos, df$time, sum)

## Plot the surveillance results
plot(n_negative, type = "l", xlab = "Time", ylab = "Count", col = "blue")
lines(n_positive, col = "red")

## Set the parameter values
gdata <- c(beta = 0.1,
           gamma = 0.07,
           n_samples = 5,
           sample_frequency = 0,
           Se = 0.6,
           alpha = 1000)

## define a third column in the select matrix for the events. When
## select = 3 then the 'sample' compartment will be affected.
E <- matrix(c(1, 1, 0,
              0, 1, 0,
              0, 0, 1,
              0, 0, 0,
              0, 0, 0),
            byrow = TRUE,
            ncol = 3,
            dimnames = list(compartments))

## Generate 100 random sampling events. Start the sampling after 150
## days since during the the first period the model is more affected
## by the initial state where every herd was infected:
events <- events_SISe()
sample_events <- data.frame(event = "enter",
                            time = sample(as.integer(tspan[tspan > 150]), 100, replace = TRUE),
                            node = sample(as.numeric(rownames(u0)), 100, replace = TRUE),
                            dest = 0,
                            n = 1,
                            proportion = 0,
                            select = 3,
                            shift = 0)

## add the sampling events to the preexisting events
events <- rbind(events, sample_events)

## Combine these pieces in the mparse function to generate a model you can
## run:
model <- mparse(transitions = transitions,
                compartments = compartments,
                gdata = gdata,
                u0 = u0,
                tspan = tspan,
                events = events,
                E = E)

set.seed(23)

result <- run(model)

## Plot the herd-level prevalence
plot(result, I ~ I + S, level = 2)

## Get the results of the trajectory
df <- trajectory(result)

## Summarize the number of negative and positive per day
n_negative <- tapply(df$result_neg, df$time, sum)
n_positive <- tapply(df$result_pos, df$time, sum)

## Plot the surveillance results
plot(n_negative, type = "l", xlab = "Time", ylab = "Count", col = "blue")
lines(n_positive, col = "red")

## result <- sapply(1:20, function(x) {
##     cat(x, "\n")
##     df <- trajectory(run(model))
##     tapply(df$result_pos, df$time, sum)
## })
## 
## result <- apply(result, 1, quantile, prob = c(0.025, 0.5, 0.975))
## plot(result[2,], type = "l", ylim = c(0, 50), ylab = "Number of positive tests")
## polygon(x = c(1:1460, 1460:1),
##         y = c(result[1, ], rev(result[3,])),
##         col = "grey", border = "grey")
## lines(x = 1:1460, result[2,])

knitr::include_graphics("img/figure_random_sample.svg")

## events <- events_SISe()
## herds <- sort(tapply(events$n, events$dest, sum),
##               decreasing = TRUE)
## herds <- herds[names(herds) != 0]
## 
## sample_events <- data.frame(event = "enter",
##                             time = sample(as.integer(tspan[tspan > 150]), 100, replace = TRUE),
##                             node = sample(as.numeric(names(herds)), 100, replace = TRUE, prob = herds),
##                             dest = 0,
##                             n = 1,
##                             proportion = 0,
##                             select = 3,
##                             shift = 0)
## 
## ## add the sampling events to the preexisting events
## events <- rbind(events, sample_events)
## 
## ## Combine these pieces in the mparse function to generate a model you can
## ## run:
## model <- mparse(transitions = transitions,
##                 compartments = compartments,
##                 gdata = gdata,
##                 u0 = u0,
##                 tspan = tspan,
##                 events = events,
##                 E = E)
## 
## result_riskbased<- sapply(1:20, function(x) {
##     cat(x, "\n")
##     df <- trajectory(run(model))
##     tapply(df$result_pos, df$time, sum)
## })
## 
## result_riskbased <- apply(result_riskbased, 1, quantile, prob = c(0.025, 0.5, 0.975))
## plot(result_riskbased[2,], type = "l", ylim = c(0, 50), ylab = "Number of positive tests")
## polygon(x = c(1:1460, 1460:1),
##         y = c(result_riskbased[1, ], rev(result_riskbased[3,])),
##         col = "grey", border = "grey")
## lines(x = 1:1460, result_riskbased[2,])
## 
## ## Add the random sample model to the graph too:
## polygon(x = c(1:1460, 1460:1),
##         y = c(result[1, ], rev(result[3,])),
##         col = "#0000FF50", border = "#0000FF50")
## lines(x = 1:1460, result[2,], col = "#0000FF")

knitr::include_graphics("img/figure_risk_based_sample.svg")
